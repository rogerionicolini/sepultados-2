# Deixe isso vazio ou apenas use para expor funções da pasta se quiser
# EXEMPLO:
from .thread_local import set_prefeitura_ativa, get_prefeitura_ativa
