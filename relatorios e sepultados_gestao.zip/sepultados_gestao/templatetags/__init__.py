# Este arquivo torna a pasta templatetags um pacote Python.
