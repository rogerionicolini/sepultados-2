import React from "react";
export default function RelatorioExumacoes() { return <div className="p-4">Relatório: Exumações</div>; } 
