import React from "react";
export default function Cemiterios() { return <div className="p-4">Página: Cemitérios</div>; } 
