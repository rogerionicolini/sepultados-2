import React from "react";
export default function Contratos() { return <div className="p-4">Página: Contratos</div>; } 
