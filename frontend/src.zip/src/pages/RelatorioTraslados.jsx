import React from "react";
export default function RelatorioTranslados() { return <div className="p-4">Relatório: Translados</div>; } 
