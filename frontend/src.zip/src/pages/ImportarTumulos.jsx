import React from "react";
export default function ImportarTumulos() { return <div className="p-4">Página: Importar Túmulos</div>; } 
