import React from "react";
export default function Quadras() { return <div className="p-4">Página: Quadras</div>; } 
