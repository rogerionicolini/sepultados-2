import React from "react";
export default function RelatorioTumulos() { return <div className="p-4">Relatório: Túmulos</div>; } 
