import React from "react";
export default function Exumacoes() { return <div className="p-4">Página: Exumações</div>; } 
