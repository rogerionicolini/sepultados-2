import React from "react";
export default function Sepultados() { return <div className="p-4">Página: Sepultados</div>; } 
