import React from "react";
export default function ImportarSepultados() { return <div className="p-4">Página: Importar Sepultados</div>; } 
