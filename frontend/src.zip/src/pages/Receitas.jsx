import React from "react";
export default function Receitas() { return <div className="p-4">Página: Receitas</div>; } 
