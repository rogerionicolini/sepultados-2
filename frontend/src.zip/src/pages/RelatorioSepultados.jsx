import React from "react";
export default function RelatorioSepultados() { return <div className="p-4">Relatório: Sepultados</div>; } 
