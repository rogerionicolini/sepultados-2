import React from "react";
export default function ImportarQuadras() { return <div className="p-4">Página: Importar Quadras</div>; } 
