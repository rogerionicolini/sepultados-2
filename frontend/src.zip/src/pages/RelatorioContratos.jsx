import React from "react";
export default function RelatorioContratos() { return <div className="p-4">Relatório: Contratos</div>; } 
