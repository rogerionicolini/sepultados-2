import React from "react";
export default function Tumulos() { return <div className="p-4">Página: Túmulos</div>; } 
