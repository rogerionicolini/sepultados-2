import React from "react";
export default function Auditoria() { return <div className="p-4">Página: Auditoria</div>; } 
