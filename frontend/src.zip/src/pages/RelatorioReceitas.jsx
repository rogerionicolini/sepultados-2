import React from "react";
export default function RelatorioReceitas() { return <div className="p-4">Relatório: Receitas</div>; } 
