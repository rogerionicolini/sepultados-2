import React, { useEffect, useState } from "react";
import axios from "axios";

function Dados() {
  const [dados, setDados] = useState(null);
  const [logo, setLogo] = useState(null);
  const [mensagem, setMensagem] = useState("");

  useEffect(() => {
    const fetchDados = async () => {
      const token = localStorage.getItem("accessToken");
      const response = await axios.get("http://127.0.0.1:8000/api/prefeitura-logada/", {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      setDados(response.data);
    };

    fetchDados();
  }, []);

  const handleChange = (e) => {
    setDados({ ...dados, [e.target.name]: e.target.value });
  };

  const handleLogoChange = (e) => {
    setLogo(e.target.files[0]);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const token = localStorage.getItem("accessToken");

    const formData = new FormData();
    for (const key in dados) {
      formData.append(key, dados[key]);
    }
    if (logo) {
      formData.append("logo", logo);
    }

    try {
      await axios.put("http://127.0.0.1:8000/api/prefeitura-logada/", formData, {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "multipart/form-data",
        },
      });
      setMensagem("Dados atualizados com sucesso.");
    } catch (error) {
      setMensagem("Erro ao atualizar os dados.");
    }
  };

  if (!dados) return <div className="text-center text-green-900 mt-10">Carregando...</div>;

  return (
    <div className="min-h-screen flex items-center justify-center bg-[#e3efcc] px-4">
      <form onSubmit={handleSubmit} className="bg-white rounded-2xl shadow-lg p-8 w-full max-w-xl">
        <h2 className="text-2xl font-bold text-green-900 mb-6 text-center">
          Editar Dados da Prefeitura
        </h2>

        {Object.entries({
          nome: "Nome",
          responsavel: "Responsável",
          telefone: "Telefone",
          email: "E-mail",
          cnpj: "CNPJ",
          site: "Site",
          logradouro: "Logradouro",
          endereco_numero: "Número",
          endereco_bairro: "Bairro",
          endereco_cidade: "Cidade",
          endereco_estado: "Estado",
          endereco_cep: "CEP",
          clausulas_contrato: "Cláusulas do Contrato"
        }).map(([key, label]) => (
          <div key={key} className="mb-4">
            <label className="block text-sm font-medium text-gray-700 mb-1">{label}</label>
            <input
              type="text"
              name={key}
              value={dados[key] || ""}
              onChange={handleChange}
              className="w-full border border-gray-300 rounded-lg px-3 py-2"
            />
          </div>
        ))}

        <div className="mb-6">
          <label className="block text-sm font-medium text-gray-700 mb-1">Nova Logo (opcional)</label>
          <input
            type="file"
            accept="image/*"
            onChange={handleLogoChange}
            className="w-full"
          />
        </div>

        {mensagem && (
          <div className="mb-4 text-center text-sm text-green-800 font-semibold">
            {mensagem}
          </div>
        )}

        <button
          type="submit"
          className="w-full bg-green-800 hover:bg-green-900 text-white font-semibold py-2 rounded-xl transition"
        >
          Salvar Alterações
        </button>
      </form>
    </div>
  );
}

export default Dados;
