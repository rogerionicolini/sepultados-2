import React from "react";
export default function Translados() { return <div className="p-4">Página: Translados</div>; } 
