import React, { useCallback, useEffect, useMemo, useState } from "react";
import { GoogleMap, LoadScript, Polygon, DrawingManager } from "@react-google-maps/api";

/**
 * MapaCemiterio (Google Maps) — COMPLETO
 * - Detecta o ID do cemitério por prop (cemiterioId) ou pela querystring ?cemiterio=
 * - Lista quadras do backend (GET /api/quadras/?cemiterio=ID)
 * - Permite desenhar uma quadra e SALVAR (POST /api/quadras/)
 * - Mostra aviso quando não há cemitério (mas o mapa continua visível)
 */
export default function MapaCemiterio({ cemiterioId }) {
  const GOOGLE_MAPS_API_KEY = import.meta.env.VITE_GOOGLE_MAPS_API_KEY || "";
  const API_BASE = (import.meta.env.VITE_API_BASE_URL || "").replace(/\/$/, "");
  const libraries = useMemo(() => ["drawing", "geometry"], []);

  // ===== Helper CSRF =====
  const getCookie = (name) => {
    const m = document.cookie.match("(^|;)\\s*" + name + "\\s*=\\s*([^;]+)");
    return m ? m.pop() : "";
  };

  // ===== Resolver ID do cemitério =====
  const cemId = useMemo(() => {
    if (Number.isFinite(cemiterioId)) return Number(cemiterioId);
    const q = Number(new URLSearchParams(window.location.search).get("cemiterio"));
    return Number.isFinite(q) ? q : null;
  }, [cemiterioId]);

  // ===== Estado =====
  const [map, setMap] = useState(null);
  const [quadras, setQuadras] = useState([]); // [{id,codigo,poligono_mapa, cemiterio}]
  const [selecionada, setSelecionada] = useState(null); // id da selecionada
  const [desenhar, setDesenhar] = useState(false);
  const [loading, setLoading] = useState(false);

  // Rascunho (polígono recém-desenhado)
  const [draftPath, setDraftPath] = useState(null); // [{lat,lng}] | null
  const [codigo, setCodigo] = useState("");
  const [saving, setSaving] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");

  // Centro padrão (ajuste ao seu cemitério)
  const center = useMemo(() => ({ lat: -23.414, lng: -51.93 }), []);

  // Estilos
  const QUADRA_STYLE = useMemo(
    () => ({ strokeColor: "#22c55e", strokeOpacity: 0.9, strokeWeight: 2, fillColor: "#22c55e", fillOpacity: 0.15, clickable: true }),
    []
  );
  const QUADRA_STYLE_SEL = useMemo(() => ({ ...QUADRA_STYLE, strokeColor: "#166534", strokeWeight: 3, fillOpacity: 0.25 }), [QUADRA_STYLE]);
  const DRAFT_STYLE = useMemo(() => ({ strokeColor: "#0ea5e9", strokeOpacity: 1, strokeWeight: 2, fillColor: "#0ea5e9", fillOpacity: 0.1, clickable: false }), []);

  const hasGoogle = typeof window !== "undefined" && window.google && window.google.maps;
  const onLoadMap = useCallback((m) => setMap(m), []);

  const fitBoundsToPath = useCallback((path) => {
    if (!map || !hasGoogle || !path?.length) return;
    const bounds = new window.google.maps.LatLngBounds();
    path.forEach((p) => bounds.extend(p));
    map.fitBounds(bounds, { top: 24, right: 24, bottom: 24, left: 24 });
  }, [map, hasGoogle]);

  // ===== API =====
  async function apiGetQuadras() {
    if (!API_BASE || !cemId) return [];
    const url = `${API_BASE}/api/quadras/?cemiterio=${cemId}`;
    const r = await fetch(url, { credentials: "include" });
    if (!r.ok) throw new Error(`GET ${r.status}`);
    return r.json();
  }

  async function apiCreateQuadra(payload) {
    const url = `${API_BASE}/api/quadras/`;
    const r = await fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "X-CSRFToken": getCookie("csrftoken"),
      },
      credentials: "include",
      body: JSON.stringify(payload),
    });
    if (!r.ok) {
      let detail;
      try { detail = await r.json(); } catch { detail = await r.text(); }
      throw new Error(typeof detail === "string" ? detail : JSON.stringify(detail));
    }
    return r.json();
  }

  const carregar = useCallback(async () => {
    if (!cemId) return;
    setLoading(true);
    try {
      const data = await apiGetQuadras();
      setQuadras(Array.isArray(data) ? data : []);
    } finally {
      setLoading(false);
    }
  }, [cemId]);

  useEffect(() => { carregar(); }, [carregar]);

  // ===== Desenho =====
  const handlePolygonComplete = useCallback((poly) => {
    const path = poly.getPath().getArray().map((ll) => ({ lat: ll.lat(), lng: ll.lng() }));
    poly.setMap(null);
    setDraftPath(path);
    setCodigo(`Q-${Date.now()}`.slice(0, 20));
    setErrorMsg("");
    setDesenhar(false);
    fitBoundsToPath(path);
  }, [fitBoundsToPath]);

  async function salvarQuadra() {
    if (!draftPath?.length) return;
    if (!cemId) { setErrorMsg("Cemitério não identificado."); return; }
    setSaving(true);
    setErrorMsg("");
    try {
      const criado = await apiCreateQuadra({
        cemiterio: cemId,
        codigo: (codigo || `Q-${Date.now()}`).slice(0, 20),
        poligono_mapa: draftPath,
      });
      await carregar();
      setSelecionada(criado?.id || null);
      setDraftPath(null);
    } catch (e) {
      setErrorMsg(e.message || "Falha ao salvar");
    } finally {
      setSaving(false);
    }
  }

  function cancelarRascunho() {
    setDraftPath(null);
    setCodigo("");
    setErrorMsg("");
  }

  const showWarning = !cemId; // mostra aviso sem bloquear o mapa

  // ===== UI =====
  return (
    <LoadScript googleMapsApiKey={GOOGLE_MAPS_API_KEY} libraries={libraries}>
      <div className="relative w-full h-[600px] rounded-xl overflow-hidden shadow">
        <div className="absolute z-[5] top-3 right-3 flex gap-2">
          <button
            className="bg-white/95 backdrop-blur px-3 py-2 rounded-lg shadow text-sm hover:bg-neutral-100"
            onClick={() => setDesenhar((v) => !v)}
            disabled={!!draftPath}
            title={draftPath ? "Conclua o salvamento do rascunho" : "Desenhar quadra"}
          >{desenhar ? "Cancelar desenho" : "Desenhar quadra"}</button>
          <button className="bg-white/95 backdrop-blur px-3 py-2 rounded-lg shadow text-sm hover:bg-neutral-100" onClick={carregar}>Recarregar</button>
        </div>

        {showWarning && (
          <div className="absolute z-[6] top-3 left-3 bg-yellow-50 border border-yellow-200 rounded-md px-3 py-2 text-xs sm:text-sm">
            Selecione um cemitério (param <code>?cemiterio=</code> na URL) ou passe <code>cemiterioId</code> no componente para salvar.
          </div>
        )}

        {/* Painel de salvar */}
        {draftPath && (
          <div className="absolute z-[6] top-16 right-3 bg-white/95 backdrop-blur rounded-xl shadow p-3 w-[260px]">
            <div className="font-medium mb-2">Salvar quadra</div>
            <label className="block text-xs text-neutral-600 mb-1">Código</label>
            <input
              value={codigo}
              onChange={(e) => setCodigo(e.target.value.slice(0, 20))}
              className="w-full border rounded-md px-2 py-1 text-sm mb-2"
              placeholder="ex.: Q1"
              maxLength={20}
            />
            {errorMsg && <div className="text-red-600 text-xs mb-2 break-words">{errorMsg}</div>}
            <div className="flex gap-2 justify-end">
              <button onClick={cancelarRascunho} className="px-2 py-1 text-sm rounded-md border">Cancelar</button>
              <button onClick={salvarQuadra} disabled={saving || !cemId} className="px-2 py-1 text-sm rounded-md bg-emerald-600 text-white disabled:opacity-60">
                {saving ? "Salvando…" : "Salvar"}
              </button>
            </div>
          </div>
        )}

        <GoogleMap
          onLoad={onLoadMap}
          mapContainerStyle={{ width: "100%", height: "100%" }}
          center={center}
          zoom={18}
          options={{ mapTypeId: "satellite", streetViewControl: false, fullscreenControl: false, mapTypeControl: true, tilt: 0 }}
        >
          {desenhar && hasGoogle && (
            <DrawingManager
              options={{
                drawingControl: true,
                drawingControlOptions: {
                  drawingModes: [window.google.maps.drawing.OverlayType.POLYGON],
                  position: window.google.maps.ControlPosition.TOP_CENTER,
                },
                polygonOptions: { ...QUADRA_STYLE, editable: false },
              }}
              onPolygonComplete={handlePolygonComplete}
              onOverlayComplete={(e) => {
                if (e.type === window.google.maps.drawing.OverlayType.POLYGON) handlePolygonComplete(e.overlay);
                else e.overlay?.setMap(null);
              }}
            />
          )}

          {/* Quadras vindas do backend */}
          {quadras.map((q) => (
            <Polygon
              key={q.id}
              paths={q.poligono_mapa || []}
              options={selecionada === q.id ? QUADRA_STYLE_SEL : QUADRA_STYLE}
              onClick={() => { setSelecionada(q.id); fitBoundsToPath(q.poligono_mapa || []); }}
            />
          ))}

          {/* Rascunho (ainda não salvo) */}
          {draftPath && (
            <Polygon paths={draftPath} options={DRAFT_STYLE} />
          )}
        </GoogleMap>

        {loading && (
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
            <div className="bg-white/80 rounded-xl px-4 py-2 text-sm shadow">Carregando quadras…</div>
          </div>
        )}
      </div>
    </LoadScript>
  );
}
